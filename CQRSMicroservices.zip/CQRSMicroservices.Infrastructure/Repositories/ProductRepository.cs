using System.Collections.Immutable;
using CQRSMicroservices.Domain.BuildingBlocks;
using CQRSMicroservices.Domain.Product;
using Microsoft.EntityFrameworkCore;

namespace CQRSMicroservices.Infrastructure.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationContext _context;
        public IUnitOfWork UnitOfWork
        {
            get
            {
                return _context;
            }
        }

        public ProductRepository(ApplicationContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public Products Add(Products product)
        {
            return _context.Products.Add(product).Entity;
        }

        public async Task<Products?> GetByIdAsync(Guid id)
        {
            var product = await _context.Products.FirstOrDefaultAsync(x => x.Id == id);

            if (product != null)
            {
                return product;
            }

            return null;
        }

        public async Task<List<Products>?> GetAllProducts()
        {
            var products = await _context.Products.AsNoTracking().ToListAsync();
            if (products != null)
            {
                return products;
            }

            return null;
        }
    }
}