using CQRSMicroservices.Domain.BuildingBlocks;

namespace CQRSMicroservices.Domain.Product
{
    //This is just the RepositoryContracts or Interface defined at the Domain Layer
    //as requisite for the Order Aggregate

    public interface IProductRepository : IRepository<Products>
    {
        Products Add(Products product);
        Task<Products>? GetByIdAsync(Guid id);
        Task<List<Products>?> GetAllProducts();
    }
}
