using System;
using System.Security.Cryptography.X509Certificates;
using CQRSMicroservices.Domain.BuildingBlocks;

namespace CQRSMicroservices.Domain.Product
{
    public class Products : IAggregateRoot
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public int Mrp { get; set; }
        public double SellingPrice { get; set; }
        public DateTime Date { get; set; }
        public string? Description { get; set; }
        public string? HSNCode { get; set; }
    }
}
