﻿namespace CQRSMicroservices.Domain.BuildingBlocks
{
   
    public interface IAggregateRoot { }

}
