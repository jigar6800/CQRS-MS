﻿namespace CQRSMicroservices.Domain.BuildingBlocks
{
    public interface IRepository<T> where T : IAggregateRoot
    {
        IUnitOfWork UnitOfWork { get; }
    }
}
