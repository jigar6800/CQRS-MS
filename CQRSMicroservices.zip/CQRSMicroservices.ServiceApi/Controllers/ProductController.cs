using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using CQRSMicroservices.ServiceApi.Application.Queries;
using System.Net;
using CQRSMicroservices.ServiceApi.Application.Commands;
using MediatR;

namespace CQRSMicroservices.ServiceApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductQueries _productQueries;
        private readonly IMediator _mediator;
        public ProductController(IProductQueries productQueries, IMediator mediator)
        {
            _productQueries = productQueries;
            _mediator = mediator;
        }

        [HttpGet]
        // [ProducesResponseType(typeof(List<CatalogType>), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var products = await _productQueries.GetAllProducts();
                return Ok(products);
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            try
            {
                var product = await _productQueries.GetProductById(id);
                return Ok(product);
            }
            catch
            {
                return BadRequest();
            }
        }

        [Route("AddProduct")]
        [HttpPost]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> AddProduct([FromBody] AddProductCommand command)
        {
            try
            {
                var result = await _mediator.Send(command);
                return Ok(result);
            }
            catch
            {
                return BadRequest();
            }
        }


    }
}