using CQRSMicroservices.Domain.Product;
using CQRSMicroservices.ServiceApi.Application.Queries;
using MediatR;

namespace CQRSMicroservices.ServiceApi.Application.Commands
{
    public class AddProductCommandHandler : IRequestHandler<AddProductCommand, Boolean>
    {
        private readonly IProductRepository _productRepository;

        public AddProductCommandHandler(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public async Task<Boolean> Handle(AddProductCommand request, CancellationToken cancellationToken)
        {
            try
            {
                //Data binding
                var Product = new Products
                {
                    Id = Guid.NewGuid(),
                    Date = DateTime.Now,
                    Mrp = 32 + (int)(request.SellingPrice / 0.5556),
                    Name = request.Name,
                    SellingPrice = request.SellingPrice,
                    Description = request.Description,
                    HSNCode = request.HSNCode
                };

                //repository
                var newProduct = _productRepository.Add(Product);

                var result = await _productRepository.UnitOfWork.SaveEntitiesAsync(cancellationToken);

                return result;
            }
            catch (System.Exception)
            {
                return false;
            }
        }
    }
}