using System.Runtime.Serialization;
using CQRSMicroservices.Domain.Product;
using CQRSMicroservices.ServiceApi.Application.Queries;
using MediatR;

namespace CQRSMicroservices.ServiceApi.Application.Commands
{
    public class AddProductCommand : IRequest<Boolean>
    {
        public string? Name { get; set; }
        public int SellingPrice { get; set; }
        public string? Description { get; set; }
        public string? HSNCode { get; set; }
    }
}