using System;

namespace CQRSMicroservices.ServiceApi.Application.Queries
{
    public class ProductModel
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public int Mrp { get; set; }
        public double SellingPrice { get; set; }
        public DateTime Date { get; set; }
    }
}
