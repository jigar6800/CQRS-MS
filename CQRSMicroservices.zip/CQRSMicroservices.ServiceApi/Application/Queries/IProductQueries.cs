namespace CQRSMicroservices.ServiceApi.Application.Queries
{
    using System;
    using System.Collections.Generic;
    using CQRSMicroservices.Domain.Product;

    public interface IProductQueries
    {
        Task<List<Products>?> GetAllProducts();
        Task<ProductModel>? GetProductById(Guid id);
    }
}
