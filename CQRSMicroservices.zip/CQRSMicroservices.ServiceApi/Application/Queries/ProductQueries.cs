
using CQRSMicroservices.Domain.Product;

namespace CQRSMicroservices.ServiceApi.Application.Queries
{
    public class ProductQueries : IProductQueries
    {
        private readonly IProductRepository _productRepository;
        public ProductQueries(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public async Task<List<Products>?> GetAllProducts()
        {
            var products = await _productRepository.GetAllProducts();

            return products;
        }

        public async Task<ProductModel> GetProductById(Guid id)
        {
            var product = await _productRepository.GetByIdAsync(id);

            return new ProductModel
            {
                Id = product.Id,
                Name = product.Name,
                Mrp = product.Mrp,
                Date = product.Date,
                SellingPrice = product.SellingPrice
            };
        }

       
    }
}
