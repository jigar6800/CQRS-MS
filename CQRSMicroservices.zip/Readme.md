Execute below command from solution directory

Build Gateway
docker build -t gateway-api -f CQRSMicroservices.GatewayApi\Dockerfile .

Build Service
docker build -t service-api -f CQRSMicroservices.ServiceApi\Dockerfile .

Compose
docker compose up -d

Entity Commands(CMD)
New : dotnet ef migrations add {migrationName}
Update DB : dotnet ef database update
Script : dotnet ef migrations script